/*
Template Name: Dason - Admin & Dashboard Template
Author: Themesdesign
Website: https://themesdesign.in/
Contact: themesdesign.in@gmail.com
File: ecommerce cart Js File
*/

//Bootstrap-TouchSpin
$("input[name='demo_vertical']").TouchSpin({
    verticalbuttons: true
});