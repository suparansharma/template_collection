<?php
header('Location: welcome.html');
die();
?>